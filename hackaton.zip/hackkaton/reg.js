var http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const serve   = require('express-static');





// Parse application/x-www-form-urlencoded
http.createServer(function (req, res)
{
    app.use(bodyParser.urlencoded({ extended: false }))

    app.use(serve(__dirname + '/'));

    app.use(express.static('img')) 
    //fileServer.serve(req, res);
})


//vendor/fontawesome-free/css/all.min.css


app.get('/register', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/register.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });
    
});


app.use(serve(__dirname + '/'));



app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}`);
});
