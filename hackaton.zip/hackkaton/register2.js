var http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
var nStatic = require('node-static');
var fileServer = new nStatic.Server('./public');

// Parse application/x-www-form-urlencoded
http.createServer(function (req, res) {
app.use(bodyParser.urlencoded({ extended: false }))
app.use(express.static("./app/public"));
app.use(express.static('img')) 
fileServer.serve(req, res);
})
//vendor/fontawesome-free/css/all.min.css

staticList.forEach(e=>{
    app.get(e, (req, res, next) => {
        res.sendFile(e, {root: __dirname});
    });
})


app.get('/register', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/register.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });
    
});

app.get('/all.min.css', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'Text/css; charset=UTF-8'
        }
    };
    res.sendFile('/all.min.css', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });

});

app.get('/sb-admin-2-min.css', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'Text/css; charset=UTF-8'
        }
    };
    res.sendFile('/sb-admin-2-min.css', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });

});
app.post('/api/users/create', (req, res) => {
    let firstname = req.body.firstname;
    let surname = req.body.surname;
    let age = req.body.age;
    let gender = req.body.gender;
    let email = req.body.email;
    let password = req.body.password;

    // Assume that we save it to db
    console.log('Saved to the database.');
    res.send([
        'Signup completed',
        `Firstname: ${firstname}`,
        `Surname: ${surname}`,
        `Age: ${age}`,
        `gender: ${gender}`,
        `Email: ${email}`,
        `Password: ${'*'.repeat(password.length)}`,
        '<a href="/signup">Back</>'
    ].join('<br>'));
});
app.get('/submit', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/index.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: index.html');
        }
    });

});
app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}`);
});