var http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const serve   = require('express-static');
var fileServer = new nStatic.Server('./public');

// Parse application/x-www-form-urlencoded
http.createServer(function (req, res)
{
    app.use(bodyParser.urlencoded({ extended: false }))

    app.use(serve(__dirname + '/public'));
    app.use(serve(__dirname + '/img'));

    app.use(express.static('img')) 
    fileServer.serve(req, res);
})



app.get('/register', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/register.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });
    
});


app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}`);
});
