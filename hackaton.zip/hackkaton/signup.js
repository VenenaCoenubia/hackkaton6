const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
app.use(express.static("./app/public"));
app.use(express.static('img')) 

app.get('/signup', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/signup.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });
    
});
app.get('/venena.jpg', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'Image/jpg; charset=UTF-8'
        }
    };
    res.sendFile('/venena.jpg', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });

});

app.post('/api/users/create', (req, res) => {
    let name = req.body.name;
    let email = req.body.email;
    let password = req.body.password;

    // Assume that we save it to db
    console.log('Saved to the database.');
    res.send([
        'Signup completed',
        `Name: ${name}`,
        `Email: ${email}`,
        `Password: ${'*'.repeat(password.length)}`,
        '<a href="/signup">Back</>'
    ].join('<br>'));
});
app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}`);
});
