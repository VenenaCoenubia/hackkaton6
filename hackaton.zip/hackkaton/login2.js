var http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
var nStatic = require('node-static');
var fileServer = new nStatic.Server('./public');

// Parse application/x-www-form-urlencoded
http.createServer(function (req, res) {
app.use(bodyParser.urlencoded({ extended: false }))
//app.use(express.static("./app/public"));
app.use(express.static('img')) 
app.use(express.static('css')) 
app.use(express.static('js')) 
fileServer.serve(req, res);
})
//vendor/fontawesome-free/css/all.min.css

staticList.forEach(e=>{
    app.get(e, (req, res, next) => {
        res.sendFile(e, {root: __dirname});
    });
})



app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}`);
});
