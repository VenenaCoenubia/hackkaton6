var http = require('http');
var mysql = require('mysql2');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const serve = require('express-static');

// app.use(bodyParser({extended: true}))
app.use(express.json())

// create connection
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "QueenVenena0",
    database: "hackkaton",
    namedPlaceholders: true
});

//Connect Db

con.connect(function (err, conn) {
    if (err) throw err;
    console.log("Connected!", conn);
});

// Parse application/x-www-form-urlencoded
http.createServer(function (req, res)
{
    app.use(bodyParser.urlencoded({ extended: false }))

    app.use(serve(__dirname + '/'));

    app.use(express.static('img')) 
    //fileServer.serve(req, res);
})


//
//      WEB FRONTEND
//
//
app.get('/Find', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/Find.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: Find.html');
        }
    });
    
});
app.get('/all.min.css', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'Text/css; charset=UTF-8'
        }
    };
    res.sendFile('/all.min.css', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: Find.html');
        }
    });

});

app.get('/sb-admin-2-min.css', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'Text/css; charset=UTF-8'
        }
    };
    res.sendFile('/sb-admin-2-min.css', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: Find.html');
        }
    });

});

app.get('/home', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/index.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: index.html');
        }
    });

});

app.get('/Result', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/Result.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: Result.html');
        }
    });

});

app.get('/Result3200055', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/Result3200055.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: Result3200055.html');
        }
    });

});
app.get('/Result3200161', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/Result3200161.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: Result3200161.html');
        }
    });

});

app.get('/Result3203130', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/Result3203130.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: Result3203130.html');
        }
    });

});

app.post('/api/users/Find', (req, res) => {
    console.log({ body: req.body })
    let EntityId = req.body.EntityId;

    if (!EntityId) return res.send("error, no EntityId")

    const sql = "SELECT * FROM bucketentity WHERE EntityId = :Eid;"
    con.execute(sql, {
        Eid: EntityId,

    }
    , (err, result) => {
        if (err) {
            return res.status(500).json({
                status: -1,
                msg: "unknown error"
            })
        }

        if(result.length == 0) return res.status(400).json({
            status: -1,
            msg: "EntityId wrong"
        })

        return res.status(200).json({
            status: 0,
            msg: "ok"
        })
})
})

app.get("/Result", (request,response) =>{
    let sql = "SELECT .* from bucketentity WHERE EntityId = :Eid "

    conn.query(sql, function(error,results,fiels){
        if (error){
            console.log(error)
        } else{
            response.render("home",
            {
                resultsEntityId : results
            })
        }
    })
})

app.use(serve(__dirname + '/'));


app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}`);
});
