const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
app.use(express.static("./app/public"));
app.use(express.static('img')) 

//vendor/fontawesome-free/css/all.min.css

const staticList = [
    "/vendor/fontawesome-free/css/all.min.css",
    "/css/sb-admin-2.min.css",
    "/vendor/jquery/jquery.min.js",
    "/vendor/bootstrap/js/bootstrap.bundle.min.js",
    "/vendor/jquery-easing/jquery.easing.min.js",
    "/js/sb-admin-2.min.js",

    "/vendor/chart.js/Chart.min.js",
    "/img/undraw_rocket.svg",
    "/img/undraw_profile_1.svg",
    "/img/undraw_profile_2.svg",
    "/img/undraw_profile_3.svg",
    "/img/undraw_profile.svg",
    "/img/undraw_posting_photo.svg",
    "/js/demo/chart-area-demo.js",
    "/js/demo/chart-pie-demo.js",
    "/vendor/fontawesome-free/webfonts/fa-solid-900.woff2",
    "/vendor/fontawesome-free/webfonts/fa-solid-900.woff",
    "/vendor/fontawesome-free/webfonts/fa-solid-900.ttf"
]

staticList.forEach(e=>{
    app.get(e, (req, res, next) => {
        res.sendFile(e, {root: __dirname});
    });
})


app.get('/register', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/register.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });
    
});

app.get('/all.min.css', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'Text/css; charset=UTF-8'
        }
    };
    res.sendFile('/all.min.css', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });

});

app.get('/sb-admin-2-min.css', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'Text/css; charset=UTF-8'
        }
    };
    res.sendFile('/sb-admin-2-min.css', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });

});
app.post('/api/users/create', (req, res) => {
    let name = req.body.name;
    let email = req.body.email;
    let password = req.body.password;

    // Assume that we save it to db
    console.log('Saved to the database.');
    res.send([
        'Signup completed',
        `Name: ${name}`,
        `Email: ${email}`,
        `Password: ${'*'.repeat(password.length)}`,
        '<a href="/signup">Back</>'
    ].join('<br>'));
});
app.get('/submit', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/index.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: index.html');
        }
    });
    
});
app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}`);
});
