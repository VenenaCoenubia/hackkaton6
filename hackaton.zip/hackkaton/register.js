var http = require('http');
var mysql = require('mysql2');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const serve = require('express-static');

// app.use(bodyParser({extended: true}))
app.use(express.json())

// create connection
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "QueenVenena0",
    database: "regis",
    namedPlaceholders: true
});

//Connect Db

con.connect(function (err, conn) {
    if (err) throw err;
    console.log("Connected!", conn);
});


// Parse application/x-www-form-urlencoded
http.createServer(function (req, res)
{
    app.use(bodyParser.urlencoded({ extended: false }))

    app.use(serve(__dirname + '/'));

    app.use(express.static('img')) 
    //fileServer.serve(req, res);
})


//
//      WEB FRONTEND
//
//

app.get('/login', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/login.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: login.html');
        }
    });
    
});
app.get('/all.min.css', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'Text/css; charset=UTF-8'
        }
    };
    res.sendFile('/all.min.css', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: login.html');
        }
    });

});

app.get('/sb-admin-2-min.css', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'Text/css; charset=UTF-8'
        }
    };
    res.sendFile('/sb-admin-2-min.css', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: login.html');
        }
    });

});

app.get('/home', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/index.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: index.html');
        }
    });

});


//vendor/fontawesome-free/css/all.min.css


app.get('/register', (req, res, next) => {
    let options = {
        root: __dirname,
        headers: {
            'Content-Type': 'text/html; charset=UTF-8'
        }
    };
    res.sendFile('/register.html', options, function (err) {
        if (err) {
            next(err);
        } else {
            console.log('Sent: register.html');
        }
    });

});

//
//      API
//
//

app.post('/api/users/create', (req, res) => {
    console.log({ body: req.body })
    let firstname = req.body.firstname;
    let surname = req.body.surname;
    let age = req.body.age;
    let gender = req.body.gender;
    let email = req.body.email;
    let password = req.body.password;

    if (!firstname) return res.send("error, no firstname")
    if (!surname) return res.send("error, no surname")
    if (!age) return res.send("error, no age")
    if (!gender) return res.send("error, no gender")
    if (!email) return res.send("error, no email")
    if (!password) return res.send("error, no password")

    const sql = "INSERT INTO user (`email`,`password`,`Name`,`Surname`,`Age`,`gender`) VALUE (:mail, :pass, :name, :surname, :age, :gender);"
    con.execute(sql, {
        mail: email,
        pass: password,
        name: firstname,
        surname: surname,
        age: age,
        gender: gender
    }, (err, result) => {
        if (err) {
            console.log({ err })
            if (err.code == "ER_DUP_ENTRY") {
                return res.status(400).json({
                    status: -1,
                    msg: "duplicate data"
                })
            }
            return res.status(500).json({
                status: -1,
                msg: "unknown error"
            })
        }
        return res.status(200).json({
            status: 0,
            msg: "ok"
        })
    })
});

app.post('/api/users/login', (req, res) => {
    console.log({ body: req.body })
    let email = req.body.email;
    let password = req.body.password;

    if (!email) return res.send("error, no mail")
    if (!password) return res.send("error, no password")

    const sql = "SELECT * FROM user WHERE email = :mail AND password = :pass;"
    con.execute(sql, {
        mail: email,
        pass: password,
    }, (err, result) => {
        if (err) {
            return res.status(500).json({
                status: -1,
                msg: "unknown error"
            })
        }

        if(result.length == 0) return res.status(400).json({
            status: -1,
            msg: "username, password wrong"
        })

        return res.status(200).json({
            status: 0,
            msg: "ok"
        })
    })
});


app.use(serve(__dirname + '/'));



app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}`);
});
